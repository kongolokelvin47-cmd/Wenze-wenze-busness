"use client";
import { useCurrency } from "./CurrencyProvider";

export default function CurrencyToggle() {
  const { display, setDisplay, rate } = useCurrency();
  return (
    <div className="cur" role="group" aria-label={`Devise (1 $ = ${rate} FC)`}>
      {["CDF", "USD"].map((c) => (
        <button key={c} className={display === c ? "on" : ""} aria-pressed={display === c} onClick={() => setDisplay(c)}>
          {c === "CDF" ? "FC" : "$"}
        </button>
      ))}
    </div>
  );
}
