"use client";
import { useEffect, useState } from "react";

export default function InstallPrompt() {
  const [evt, setEvt] = useState(null);

  useEffect(() => {
    const onPrompt = (e) => {
      e.preventDefault();
      setEvt(e);
    };
    const onInstalled = () => setEvt(null);
    window.addEventListener("beforeinstallprompt", onPrompt);
    window.addEventListener("appinstalled", onInstalled);
    return () => {
      window.removeEventListener("beforeinstallprompt", onPrompt);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  if (!evt) return null;

  const install = async () => {
    evt.prompt();
    await evt.userChoice;
    setEvt(null);
  };

  return (
    <div className="install" role="dialog" aria-label="Installer l'application">
      <span>Installez Wenze Wenze sur votre téléphone</span>
      <button onClick={install}>Installer</button>
      <button className="ghost" onClick={() => setEvt(null)} aria-label="Fermer">✕</button>
    </div>
  );
}
