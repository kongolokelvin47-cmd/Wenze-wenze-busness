"use client";
import { useState } from "react";
import Link from "next/link";
import { supabase } from "../lib/supabase";
import { errMsg } from "../lib/errors";
import { useAuth } from "../AuthProvider";

export default function Connexion() {
  const { user, account, loading, signOut } = useAuth();
  const [mode, setMode] = useState("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState(null);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    const { data, error } =
      mode === "login"
        ? await supabase.auth.signInWithPassword({ email, password })
        : await supabase.auth.signUp({ email, password, options: { emailRedirectTo: window.location.origin } });
    setBusy(false);
    if (error) return setMsg({ type: "err", text: errMsg(error) });
    if (mode === "signup" && !data.session)
      setMsg({ type: "ok", text: "Compte créé. Vérifiez votre boîte mail pour confirmer votre adresse." });
  }

  if (loading) return <div className="app"><p className="note">Chargement…</p></div>;

  if (user) {
    const plan = account?.plan || "buyer";
    const planLabel = { buyer: "Acheteur (gratuit)", free: "Vendeur Freemium", pro: "Vendeur Pro", b2b: "Grossiste B2B" }[plan];
    return (
      <div className="app">
        <header className="top"><h1 className="page-title" style={{ paddingLeft: 0 }}>Mon compte</h1></header>
        <div className="card" style={{ gap: 8 }}>
          <b>{account?.display_name || user.email}</b>
          <small className="note">{user.email}</small>
          <span className="rating">Formule : {planLabel}</span>
          {account?.is_seller && plan === "free" && (
            <span className="rating">Annonces gratuites restantes : {account.free_listings_left} / 3 (à vie)</span>
          )}
          {account?.plan_expires_at && (plan === "pro" || plan === "b2b") && (
            <span className="rating">Valable jusqu'au {new Date(account.plan_expires_at).toLocaleDateString("fr-FR")}</span>
          )}
        </div>
        <div className="stack" style={{ marginTop: 14 }}>
          <Link href="/vendre" className="btn block">{account?.is_seller ? "Publier / gérer mes annonces" : "Devenir vendeur"}</Link>
          {account?.is_seller && <Link href="/campagnes" className="btn block ghost-btn">Mes campagnes publicitaires</Link>}
          <Link href="/tarifs" className="btn block ghost-btn">Voir les tarifs</Link>
          {account?.is_admin && <Link href="/admin" className="btn block ghost-btn">Administration</Link>}
          <button className="btn block ghost-btn" onClick={signOut}>Se déconnecter</button>
        </div>
      </div>
    );
  }

  return (
    <div className="app">
      <header className="top"><h1 className="page-title" style={{ paddingLeft: 0 }}>{mode === "login" ? "Connexion" : "Créer un compte"}</h1></header>
      <form className="form" onSubmit={submit}>
        <label>Email
          <input type="email" required autoComplete="email" value={email} onChange={(e) => setEmail(e.target.value)} />
        </label>
        <label>Mot de passe
          <input type="password" required minLength={6} autoComplete={mode === "login" ? "current-password" : "new-password"} value={password} onChange={(e) => setPassword(e.target.value)} />
        </label>
        {msg && <p className={`msg ${msg.type}`}>{msg.text}</p>}
        <button className="btn block" disabled={busy}>{busy ? "Patientez…" : mode === "login" ? "Se connecter" : "Créer mon compte"}</button>
        <button type="button" className="link" onClick={() => { setMode(mode === "login" ? "signup" : "login"); setMsg(null); }}>
          {mode === "login" ? "Pas encore de compte ? Inscrivez-vous" : "Déjà un compte ? Connectez-vous"}
        </button>
      </form>
    </div>
  );
}
