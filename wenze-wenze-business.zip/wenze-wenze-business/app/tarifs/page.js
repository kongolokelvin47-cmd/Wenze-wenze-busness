import Link from "next/link";
import Price from "../Price";
import CurrencyToggle from "../CurrencyToggle";
import { plans, ads } from "../data";

export const metadata = { title: "Tarifs – Wenze Wenze Business" };

export default function Tarifs() {
  return (
    <div className="app">
      <header className="top">
        <Link href="/" className="back" aria-label="Retour à l'accueil">←</Link>
        <h1 className="page-title">Tarifs</h1>
        <CurrencyToggle />
      </header>

      <section className="section">
        <div className="section-head"><h2>Abonnements</h2></div>
        <div className="stack">
          {plans.map((p) => (
            <article key={p.id} className="card plan">
              <div className="plan-head">
                <b>{p.name}</b>
                <span className="plan-price">
                  {p.price.amount === 0 ? "Gratuit" : <Price m={p.price} />}
                  <small>{p.period}</small>
                </span>
              </div>
              <ul>{p.features.map((f) => <li key={f}>{f}</li>)}</ul>
              {(p.id === "pro" || p.id === "b2b") && (
                <Link href={`/abonnement?formule=${p.id}`} className="btn small" style={{ justifySelf: "start", marginTop: 8 }}>Souscrire</Link>
              )}
            </article>
          ))}
        </div>
      </section>

      <section className="section">
        <div className="section-head"><h2>Publicité et publication</h2></div>
        <div className="stack">
          {ads.map((a) => (
            <article key={a.id} className="card plan">
              <div className="plan-head">
                <b>{a.name}</b>
                <span className="plan-price"><Price m={a.price} /><small>{a.period}</small></span>
              </div>
              <p className="note">{a.note}</p>
              {a.kind && (
                <Link href={`/campagnes?formule=${a.kind}`} className="btn small" style={{ justifySelf: "start", marginTop: 8 }}>Créer une campagne</Link>
              )}
            </article>
          ))}
        </div>
        <p className="legal">Prix hors frais de paiement. Aucune garantie de vues, de contacts ou de ventes. Campagnes validées avant diffusion, sans renouvellement automatique.</p>
      </section>
    </div>
  );
}
