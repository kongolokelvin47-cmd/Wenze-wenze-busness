"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { supabase } from "../lib/supabase";
import { errMsg } from "../lib/errors";
import { compressImage } from "../lib/image";
import { useAuth } from "../AuthProvider";
import Price from "../Price";

const METHODS = [
  ["orange_money", "Orange Money"],
  ["mpesa", "M-Pesa"],
  ["airtel_money", "Airtel Money"],
  ["autre", "Autre"],
];
const STATUS = { pending: "En attente de validation", approved: "Validé", rejected: "Rejeté" };

export default function Abonnement() {
  const { user, account, loading, refresh } = useAuth();
  const [offers, setOffers] = useState([]);
  const [kind, setKind] = useState("pro");
  const [instructions, setInstructions] = useState("");
  const [requests, setRequests] = useState([]);
  const [method, setMethod] = useState("orange_money");
  const [reference, setReference] = useState("");
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState(null);

  const load = useCallback(async () => {
    const [o, s, r] = await Promise.all([
      supabase.from("ww_offers").select("kind,label,price_usd,duration_days").in("kind", ["pro", "b2b"]).order("price_usd"),
      supabase.from("ww_settings").select("value").eq("key", "payment_instructions").maybeSingle(),
      supabase.from("ww_payment_requests").select("id,kind,amount_usd,method,reference,status,admin_note,created_at").order("created_at", { ascending: false }).limit(10),
    ]);
    setOffers(o.data || []);
    setInstructions(s.data?.value || "");
    setRequests(r.data || []);
  }, []);

  useEffect(() => {
    const f = new URLSearchParams(window.location.search).get("formule");
    if (f === "pro" || f === "b2b") setKind(f);
  }, []);
  useEffect(() => { if (user) load(); }, [user, load]);

  async function submit(e) {
    e.preventDefault();
    if (!file) return setMsg({ type: "err", text: "Ajoutez la capture d'écran de la preuve de paiement." });
    setBusy(true);
    setMsg(null);
    try {
      const blob = await compressImage(file, 1400, 0.8);
      const path = `${user.id}/${crypto.randomUUID()}.jpg`;
      const { error: upErr } = await supabase.storage.from("ww-proofs").upload(path, blob, { contentType: "image/jpeg" });
      if (upErr) throw upErr;
      const { error } = await supabase.from("ww_payment_requests").insert({ kind, method, reference: reference.trim(), proof_path: path });
      if (error) {
        await supabase.storage.from("ww-proofs").remove([path]);
        throw error;
      }
      setReference("");
      setFile(null);
      setMsg({ type: "ok", text: "Demande envoyée. Elle sera validée après vérification du paiement." });
      load();
      refresh();
    } catch (err) {
      setMsg({ type: "err", text: errMsg(err) });
    }
    setBusy(false);
  }

  if (loading) return <div className="app"><p className="note">Chargement…</p></div>;

  if (!user || !account?.is_seller)
    return (
      <div className="app">
        <header className="top"><h1 className="page-title" style={{ paddingLeft: 0 }}>Abonnement</h1></header>
        <p className="note">{!user ? "Connectez-vous" : "Créez d'abord votre profil vendeur"} pour souscrire à une formule.</p>
        <Link href={!user ? "/connexion" : "/vendre"} className="btn block" style={{ marginTop: 12 }}>
          {!user ? "Se connecter / S'inscrire" : "Devenir vendeur"}
        </Link>
      </div>
    );

  const offer = offers.find((o) => o.kind === kind);
  const labelOf = (k) => offers.find((o) => o.kind === k)?.label || k;

  return (
    <div className="app">
      <header className="top"><h1 className="page-title" style={{ paddingLeft: 0 }}>Abonnement</h1></header>

      <div className="seg" role="group" aria-label="Formule">
        {offers.map((o) => (
          <button key={o.kind} className={kind === o.kind ? "on" : ""} onClick={() => setKind(o.kind)}>{o.label}</button>
        ))}
      </div>

      {offer && (
        <div className="card" style={{ marginTop: 12, gap: 6 }}>
          <b>{offer.label} · {offer.duration_days} jours</b>
          <span className="plan-price" style={{ textAlign: "left" }}><Price m={{ amount: Number(offer.price_usd), cur: "USD" }} /></span>
        </div>
      )}

      <div className="card" style={{ marginTop: 12 }}>
        <b>1. Effectuez le paiement</b>
        <p className="note" style={{ whiteSpace: "pre-line" }}>{instructions}</p>
      </div>

      <form className="form" onSubmit={submit} style={{ marginTop: 12 }}>
        <b>2. Envoyez la preuve</b>
        <label>Moyen de paiement
          <select value={method} onChange={(e) => setMethod(e.target.value)}>
            {METHODS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
          </select>
        </label>
        <label>Référence de la transaction
          <input required minLength={4} maxLength={60} value={reference} onChange={(e) => setReference(e.target.value)} />
        </label>
        <label>Capture d'écran du paiement
          <input required type="file" accept="image/*" onChange={(e) => setFile(e.target.files?.[0] || null)} />
        </label>
        {msg && <p className={`msg ${msg.type}`}>{msg.text}</p>}
        <button className="btn block" disabled={busy}>{busy ? "Envoi…" : "Envoyer ma demande"}</button>
      </form>

      {requests.length > 0 && (
        <section className="section">
          <div className="section-head"><h2>Mes demandes</h2></div>
          <div className="stack">
            {requests.map((r) => (
              <article key={r.id} className="card plan">
                <div className="plan-head">
                  <b>{labelOf(r.kind)}</b>
                  <span className="rating">{new Date(r.created_at).toLocaleDateString("fr-FR")}</span>
                </div>
                <p className="note">{STATUS[r.status]} · {r.reference}</p>
                {r.admin_note && <p className="note">Note : {r.admin_note}</p>}
              </article>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
