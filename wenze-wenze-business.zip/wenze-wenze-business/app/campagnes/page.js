"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { supabase } from "../lib/supabase";
import { errMsg } from "../lib/errors";
import { compressImage } from "../lib/image";
import { useAuth } from "../AuthProvider";
import { mediaUrl } from "../HomeAds";
import Price from "../Price";

const KINDS = ["boost", "video_exp", "video_std", "video_mon"];
const METHODS = [["orange_money", "Orange Money"], ["mpesa", "M-Pesa"], ["airtel_money", "Airtel Money"], ["autre", "Autre"]];
const MAX_VIDEO_MB = 20;
const VIDEO_EXT = { "video/mp4": "mp4", "video/webm": "webm", "video/quicktime": "mov" };

function videoDuration(file) {
  return new Promise((resolve, reject) => {
    const v = document.createElement("video");
    v.preload = "metadata";
    v.onloadedmetadata = () => { URL.revokeObjectURL(v.src); resolve(v.duration); };
    v.onerror = () => reject(new Error("video"));
    v.src = URL.createObjectURL(file);
  });
}

function PayForm({ campaign, instructions, onDone }) {
  const { user } = useAuth();
  const [method, setMethod] = useState("orange_money");
  const [reference, setReference] = useState("");
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState(null);

  async function submit(e) {
    e.preventDefault();
    if (!file) return setMsg("Ajoutez la capture d'écran de la preuve de paiement.");
    setBusy(true);
    setMsg(null);
    try {
      const blob = await compressImage(file, 1400, 0.8);
      const path = `${user.id}/${crypto.randomUUID()}.jpg`;
      const { error: upErr } = await supabase.storage.from("ww-proofs").upload(path, blob, { contentType: "image/jpeg" });
      if (upErr) throw upErr;
      const { error } = await supabase.from("ww_payment_requests").insert({
        kind: campaign.kind, campaign_id: campaign.id, method, reference: reference.trim(), proof_path: path,
      });
      if (error) {
        await supabase.storage.from("ww-proofs").remove([path]);
        throw error;
      }
      onDone();
    } catch (err) {
      setMsg(errMsg(err));
    }
    setBusy(false);
  }

  return (
    <form className="form" onSubmit={submit} style={{ marginTop: 8 }}>
      <p className="note" style={{ whiteSpace: "pre-line" }}>{instructions}</p>
      <label>Moyen de paiement
        <select value={method} onChange={(e) => setMethod(e.target.value)}>
          {METHODS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}
        </select>
      </label>
      <label>Référence de la transaction
        <input required minLength={4} maxLength={60} value={reference} onChange={(e) => setReference(e.target.value)} />
      </label>
      <label>Capture d'écran du paiement
        <input required type="file" accept="image/*" onChange={(e) => setFile(e.target.files?.[0] || null)} />
      </label>
      {msg && <p className="msg err">{msg}</p>}
      <button className="btn block" disabled={busy}>{busy ? "Envoi…" : "Envoyer la preuve de paiement"}</button>
    </form>
  );
}

export default function Campagnes() {
  const { user, account, loading } = useAuth();
  const [offers, setOffers] = useState([]);
  const [instructions, setInstructions] = useState("");
  const [listings, setListings] = useState([]);
  const [campaigns, setCampaigns] = useState([]);
  const [notes, setNotes] = useState({});
  const [payOpen, setPayOpen] = useState(null);

  const [kind, setKind] = useState("boost");
  const [title, setTitle] = useState("");
  const [listingId, setListingId] = useState("");
  const [file, setFile] = useState(null);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState(null);

  const load = useCallback(async () => {
    const [o, s, l, c, p] = await Promise.all([
      supabase.from("ww_offers").select("kind,label,price_usd,duration_days").in("kind", KINDS).order("price_usd"),
      supabase.from("ww_settings").select("value").eq("key", "payment_instructions").maybeSingle(),
      supabase.from("ww_listings").select("id,title").eq("seller_id", user.id).eq("status", "active").order("created_at", { ascending: false }),
      supabase.from("ww_campaigns").select("id,kind,title,media_path,media_type,status,starts_at,ends_at,created_at").eq("seller_id", user.id).order("created_at", { ascending: false }),
      supabase.from("ww_payment_requests").select("campaign_id,status,admin_note,created_at").not("campaign_id", "is", null).order("created_at", { ascending: false }),
    ]);
    setOffers(o.data || []);
    setInstructions(s.data?.value || "");
    setListings(l.data || []);
    setCampaigns(c.data || []);
    const n = {};
    for (const r of p.data || []) if (!(r.campaign_id in n)) n[r.campaign_id] = r;
    setNotes(n);
  }, [user]);

  useEffect(() => {
    const f = new URLSearchParams(window.location.search).get("formule");
    if (KINDS.includes(f)) setKind(f);
  }, []);
  useEffect(() => { if (user && account?.is_seller) load(); }, [user, account?.is_seller, load]);

  async function create(e) {
    e.preventDefault();
    setMsg(null);
    if (!file) return setMsg({ type: "err", text: "Ajoutez un fichier." });
    if (kind === "boost" && !listingId) return setMsg({ type: "err", text: "Choisissez l'annonce à promouvoir." });
    setBusy(true);
    let path = null;
    try {
      let body, contentType, ext, mediaType;
      if (kind === "boost") {
        body = await compressImage(file, 1280, 0.8);
        contentType = "image/jpeg"; ext = "jpg"; mediaType = "image";
      } else {
        if (!VIDEO_EXT[file.type]) throw new Error("fmt");
        if (file.size > MAX_VIDEO_MB * 1024 * 1024) throw new Error("size");
        const d = await videoDuration(file);
        if (d > 60) throw new Error("dur");
        body = file; contentType = file.type; ext = VIDEO_EXT[file.type]; mediaType = "video";
      }
      path = `${user.id}/${crypto.randomUUID()}.${ext}`;
      const { error: upErr } = await supabase.storage.from("ww-ads").upload(path, body, { contentType });
      if (upErr) throw upErr;
      const { error } = await supabase.from("ww_campaigns").insert({
        kind, title: title.trim(), listing_id: listingId || null, media_path: path, media_type: mediaType,
      });
      if (error) { await supabase.storage.from("ww-ads").remove([path]); throw error; }
      setTitle(""); setListingId(""); setFile(null);
      setMsg({ type: "ok", text: "Campagne créée. Il reste à payer pour l'envoyer en validation." });
      await load();
    } catch (err) {
      const text = err.message === "fmt" ? "Format vidéo non accepté (MP4, WebM ou MOV)."
        : err.message === "size" ? `Vidéo trop lourde (${MAX_VIDEO_MB} Mo maximum).`
        : err.message === "dur" ? "Vidéo trop longue (60 secondes maximum, 30 conseillées)."
        : errMsg(err);
      setMsg({ type: "err", text });
    }
    setBusy(false);
  }

  async function remove(c) {
    if (!confirm("Supprimer cette campagne non payée ?")) return;
    await supabase.from("ww_campaigns").delete().eq("id", c.id);
    await supabase.storage.from("ww-ads").remove([c.media_path]);
    load();
  }

  if (loading) return <div className="app"><p className="note">Chargement…</p></div>;

  if (!user || !account?.is_seller)
    return (
      <div className="app">
        <header className="top"><h1 className="page-title" style={{ paddingLeft: 0 }}>Campagnes</h1></header>
        <p className="note">{!user ? "Connectez-vous" : "Créez d'abord votre profil vendeur"} pour lancer une campagne publicitaire.</p>
        <Link href={!user ? "/connexion" : "/vendre"} className="btn block" style={{ marginTop: 12 }}>
          {!user ? "Se connecter / S'inscrire" : "Devenir vendeur"}
        </Link>
      </div>
    );

  const offer = offers.find((o) => o.kind === kind);
  const labelOf = (k) => offers.find((o) => o.kind === k)?.label || k;
  const now = Date.now();

  const statusText = (c) => {
    if (c.status === "awaiting_payment") return "À payer";
    if (c.status === "pending_review") return "En attente de validation";
    if (c.status === "stopped") return "Arrêtée par la modération";
    if (c.ends_at && new Date(c.ends_at).getTime() < now) return "Terminée";
    return `En ligne jusqu'au ${new Date(c.ends_at).toLocaleDateString("fr-FR")}`;
  };

  return (
    <div className="app">
      <header className="top"><h1 className="page-title" style={{ paddingLeft: 0 }}>Campagnes</h1></header>

      <form className="form" onSubmit={create}>
        <label>Formule
          <select value={kind} onChange={(e) => { setKind(e.target.value); setFile(null); }}>
            {offers.map((o) => <option key={o.kind} value={o.kind}>{o.label} · {o.duration_days} j</option>)}
          </select>
        </label>
        {offer && (
          <div className="card" style={{ gap: 4 }}>
            <span className="plan-price" style={{ textAlign: "left" }}><Price m={{ amount: Number(offer.price_usd), cur: "USD" }} /></span>
            <small className="note">
              {kind === "boost"
                ? "1 image, 1 annonce promue, 1 emplacement dans le carrousel."
                : "1 vidéo (30 s conseillées, 60 s maximum), diffusée dans Wenze Vidéo. Aucun renouvellement automatique."}
              {" "}Aucune garantie de vues ou de ventes.
            </small>
          </div>
        )}
        <label>Titre de la campagne<input required minLength={3} maxLength={80} value={title} onChange={(e) => setTitle(e.target.value)} /></label>
        <label>{kind === "boost" ? "Annonce à promouvoir" : "Annonce liée (facultatif)"}
          <select required={kind === "boost"} value={listingId} onChange={(e) => setListingId(e.target.value)}>
            <option value="">{kind === "boost" ? "Choisir…" : "Aucune"}</option>
            {listings.map((l) => <option key={l.id} value={l.id}>{l.title}</option>)}
          </select>
        </label>
        <label>{kind === "boost" ? "Image publicitaire" : `Vidéo (MP4, WebM ou MOV, ${MAX_VIDEO_MB} Mo max)`}
          <input required key={kind} type="file" accept={kind === "boost" ? "image/*" : "video/mp4,video/webm,video/quicktime"} onChange={(e) => setFile(e.target.files?.[0] || null)} />
        </label>
        {kind === "boost" && listings.length === 0 && (
          <p className="note">Vous n'avez pas encore d'annonce en ligne. <Link href="/vendre" className="link">Publier une annonce</Link></p>
        )}
        {msg && <p className={`msg ${msg.type}`}>{msg.text}</p>}
        <button className="btn block" disabled={busy}>{busy ? "Envoi du fichier…" : "Créer la campagne"}</button>
      </form>

      {campaigns.length > 0 && (
        <section className="section">
          <div className="section-head"><h2>Mes campagnes</h2></div>
          <div className="stack">
            {campaigns.map((c) => {
              const note = notes[c.id];
              return (
                <article key={c.id} className="card plan">
                  <div className="plan-head">
                    <b>{c.title}</b>
                    <span className="rating">{labelOf(c.kind)}</span>
                  </div>
                  {c.media_type === "image"
                    ? <img src={mediaUrl(c.media_path)} alt="" className="proof" />
                    : <video src={mediaUrl(c.media_path)} controls muted playsInline preload="metadata" className="proof" />}
                  <p className="note">{statusText(c)}</p>
                  {c.status === "awaiting_payment" && note?.status === "rejected" && (
                    <p className="msg err">Paiement rejeté{note.admin_note ? ` : ${note.admin_note}` : "."} Vous pouvez renvoyer une preuve.</p>
                  )}
                  {c.status === "awaiting_payment" && (
                    <>
                      {payOpen === c.id
                        ? <PayForm campaign={c} instructions={instructions} onDone={() => { setPayOpen(null); load(); }} />
                        : <div className="two" style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                            <button className="btn small" onClick={() => setPayOpen(c.id)}>Payer</button>
                            <button className="btn small ghost-btn" onClick={() => remove(c)}>Supprimer</button>
                          </div>}
                    </>
                  )}
                </article>
              );
            })}
          </div>
        </section>
      )}
    </div>
  );
}
