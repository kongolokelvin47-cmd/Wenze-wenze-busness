"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { supabase } from "../lib/supabase";
import { errMsg } from "../lib/errors";
import { useAuth } from "../AuthProvider";
import { mediaUrl } from "../HomeAds";
import Price from "../Price";

const METHOD = { orange_money: "Orange Money", mpesa: "M-Pesa", airtel_money: "Airtel Money", autre: "Autre" };

function Media({ type, path }) {
  const url = mediaUrl(path);
  return type === "video"
    ? <video src={url} controls muted playsInline preload="metadata" className="proof" />
    : <img src={url} alt="Visuel de la campagne" className="proof" />;
}

export default function Admin() {
  const { user, account, loading } = useAuth();
  const [tab, setTab] = useState("pending");
  const [rows, setRows] = useState([]);
  const [live, setLive] = useState([]);
  const [state, setState] = useState("idle");
  const [rate, setRateInput] = useState("");
  const [instr, setInstr] = useState("");
  const [msg, setMsg] = useState(null);

  const load = useCallback(async (status) => {
    setState("loading");
    if (status === "live") {
      const { data, error } = await supabase
        .from("ww_campaigns")
        .select("id,kind,title,media_path,media_type,starts_at,ends_at,seller:ww_profiles(display_name,shop_name)")
        .eq("status", "active")
        .gt("ends_at", new Date().toISOString())
        .order("ends_at");
      if (error) { setState("error"); return setMsg({ type: "err", text: errMsg(error) }); }
      setLive(data || []);
      return setState("ready");
    }
    const { data, error } = await supabase.rpc("ww_admin_payments", { p_status: status });
    if (error) { setState("error"); return setMsg({ type: "err", text: errMsg(error) }); }
    const withUrls = await Promise.all(
      (data || []).map(async (r) => {
        if (!r.proof_path) return r;
        const { data: s } = await supabase.storage.from("ww-proofs").createSignedUrl(r.proof_path, 600);
        return { ...r, proof_url: s?.signedUrl };
      })
    );
    setRows(withUrls);
    setState("ready");
  }, []);

  const loadSettings = useCallback(async () => {
    const { data } = await supabase.from("ww_settings").select("key,value");
    for (const r of data || []) {
      if (r.key === "taux_cdf") setRateInput(r.value);
      if (r.key === "payment_instructions") setInstr(r.value);
    }
  }, []);

  useEffect(() => { if (account?.is_admin) load(tab); }, [account?.is_admin, tab, load]);
  useEffect(() => { if (account?.is_admin) loadSettings(); }, [account?.is_admin, loadSettings]);

  async function decide(r, approve) {
    let note = null;
    if (!approve) {
      note = prompt("Motif du rejet (visible par le vendeur) :", "");
      if (note === null) return;
    } else if (!confirm(`Valider « ${r.campaign_title || r.label} » pour ${r.shop_name || r.display_name} ?`)) return;
    const { error } = await supabase.rpc("ww_admin_decide_payment", { p_id: r.id, p_approve: approve, p_note: note });
    if (error) return setMsg({ type: "err", text: errMsg(error) });
    setMsg({ type: "ok", text: approve ? (r.campaign_id ? "Campagne mise en ligne." : "Abonnement activé.") : "Demande rejetée." });
    load(tab);
  }

  async function stop(c) {
    if (!confirm(`Arrêter la campagne « ${c.title} » ?`)) return;
    const { error } = await supabase.rpc("ww_admin_stop_campaign", { p_id: c.id });
    if (error) return setMsg({ type: "err", text: errMsg(error) });
    setMsg({ type: "ok", text: "Campagne arrêtée." });
    load(tab);
  }

  async function saveSettings(e) {
    e.preventDefault();
    setMsg(null);
    for (const [k, v] of [["taux_cdf", rate], ["payment_instructions", instr]]) {
      const { error } = await supabase.rpc("ww_admin_set_setting", { p_key: k, p_value: v });
      if (error) return setMsg({ type: "err", text: errMsg(error) });
    }
    setMsg({ type: "ok", text: "Réglages enregistrés. Le nouveau taux s'applique au prochain chargement de l'app." });
  }

  if (loading) return <div className="app"><p className="note">Chargement…</p></div>;
  if (!user || !account?.is_admin)
    return (
      <div className="app">
        <header className="top"><h1 className="page-title" style={{ paddingLeft: 0 }}>Administration</h1></header>
        <p className="note">Accès réservé à l'administrateur.</p>
        <Link href="/" className="btn block" style={{ marginTop: 12 }}>Retour à l'accueil</Link>
      </div>
    );

  return (
    <div className="app">
      <header className="top"><h1 className="page-title" style={{ paddingLeft: 0 }}>Administration</h1></header>
      {msg && <p className={`msg ${msg.type}`}>{msg.text}</p>}

      <div className="seg" role="group" aria-label="Statut">
        {[["pending", "À valider"], ["approved", "Validés"], ["rejected", "Rejetés"], ["live", "En ligne"]].map(([k, l]) => (
          <button key={k} className={tab === k ? "on" : ""} onClick={() => setTab(k)}>{l}</button>
        ))}
      </div>

      {state === "loading" && <p className="note">Chargement…</p>}
      {state === "ready" && (tab === "live" ? live : rows).length === 0 && <p className="note">Aucun élément.</p>}

      <div className="stack" style={{ marginTop: 12 }}>
        {tab === "live" && live.map((c) => (
          <article key={c.id} className="card plan">
            <div className="plan-head">
              <b>{c.title}</b>
              <span className="rating">jusqu'au {new Date(c.ends_at).toLocaleDateString("fr-FR")}</span>
            </div>
            <p className="note">{c.seller?.shop_name || c.seller?.display_name}</p>
            <Media type={c.media_type} path={c.media_path} />
            <button className="btn small ghost-btn" style={{ marginTop: 8 }} onClick={() => stop(c)}>Arrêter la campagne</button>
          </article>
        ))}

        {tab !== "live" && rows.map((r) => (
          <article key={r.id} className="card plan">
            <div className="plan-head">
              <b>{r.label}</b>
              <span className="plan-price"><Price m={{ amount: Number(r.amount_usd), cur: "USD" }} /></span>
            </div>
            <p className="note">
              {r.shop_name || r.display_name} · {METHOD[r.method]} · réf. <b>{r.reference}</b><br />
              WhatsApp : {r.whatsapp} · {new Date(r.created_at).toLocaleString("fr-FR")}
            </p>
            {r.campaign_id && (
              <>
                <p className="note"><b>Campagne :</b> {r.campaign_title}{r.listing_title ? ` · annonce : ${r.listing_title}` : ""}</p>
                <Media type={r.media_type} path={r.media_path} />
              </>
            )}
            {r.proof_url && (
              <a href={r.proof_url} target="_blank" rel="noopener noreferrer">
                <img src={r.proof_url} alt="Preuve de paiement" className="proof" />
              </a>
            )}
            {r.admin_note && <p className="note">Note : {r.admin_note}</p>}
            {r.status === "pending" && (
              <div className="two" style={{ marginTop: 8, display: "grid", gridTemplateColumns: "1fr 1fr", gap: 8 }}>
                <button className="btn small" onClick={() => decide(r, true)}>Valider</button>
                <button className="btn small ghost-btn" onClick={() => decide(r, false)}>Rejeter</button>
              </div>
            )}
          </article>
        ))}
      </div>

      <section className="section">
        <div className="section-head"><h2>Réglages</h2></div>
        <form className="form" onSubmit={saveSettings}>
          <label>Taux : 1 $ = … FC
            <input required inputMode="decimal" value={rate} onChange={(e) => setRateInput(e.target.value)} />
          </label>
          <label>Instructions de paiement (numéros Mobile Money, noms)
            <textarea rows={5} required value={instr} onChange={(e) => setInstr(e.target.value)} />
          </label>
          <button className="btn block">Enregistrer</button>
        </form>
      </section>
    </div>
  );
}
