"use client";
import { createContext, useContext, useEffect, useState } from "react";
import { supabase } from "./lib/supabase";
import { getRate, setRate } from "./lib/currency";

const Ctx = createContext({ display: "CDF", setDisplay: () => {}, rate: 2250 });
export const useCurrency = () => useContext(Ctx);

export default function CurrencyProvider({ children }) {
  const [display, setDisplayState] = useState("CDF");
  const [rate, setRateState] = useState(getRate());

  useEffect(() => {
    try {
      const saved = localStorage.getItem("wwb-currency");
      if (saved === "USD" || saved === "CDF") setDisplayState(saved);
    } catch {}
    // Taux officiel enregistré dans la base
    supabase
      .from("ww_settings")
      .select("value")
      .eq("key", "taux_cdf")
      .maybeSingle()
      .then(({ data }) => {
        if (data?.value) {
          setRate(Number(data.value));
          setRateState(getRate());
        }
      });
  }, []);

  const setDisplay = (c) => {
    setDisplayState(c);
    try { localStorage.setItem("wwb-currency", c); } catch {}
  };

  return <Ctx.Provider value={{ display, setDisplay, rate }}>{children}</Ctx.Provider>;
}
