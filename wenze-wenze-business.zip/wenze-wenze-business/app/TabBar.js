"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";

const tabs = [
  ["/", "🏠", "Accueil"],
  ["/categories", "🗂️", "Secteurs"],
  ["/annonces", "📣", "Annonces"],
  ["/vendre", "➕", "Vendre"],
  ["/connexion", "👤", "Compte"],
];

export default function TabBar() {
  const path = usePathname();
  return (
    <nav className="tabbar" aria-label="Navigation principale">
      {tabs.map(([href, icon, label]) => {
        const active = href === "/" ? path === "/" : path.startsWith(href);
        return (
          <Link key={href} href={href} className={active ? "active" : ""} aria-current={active ? "page" : undefined}>
            <span>{icon}</span>
            {label}
          </Link>
        );
      })}
    </nav>
  );
}
