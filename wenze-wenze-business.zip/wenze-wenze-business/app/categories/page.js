import Link from "next/link";
import { sectors } from "../data";

export const metadata = { title: "Secteurs d'activité – Wenze Wenze Business" };

export default function Categories() {
  return (
    <div className="app">
      <header className="top">
        <Link href="/" className="back" aria-label="Retour à l'accueil">←</Link>
        <h1 className="page-title">Secteurs d'activité</h1>
      </header>
      <div className="grid sectors" style={{ marginTop: 12 }}>
        {sectors.map((c) => (
          <Link key={c.id} href={`/annonces?secteur=${c.id}`} className="sector">
            <span>{c.emoji}</span>
            {c.name}
          </Link>
        ))}
      </div>
    </div>
  );
}
