"use client";
import { useCallback, useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import { sectors } from "../data";
import Price from "../Price";

export default function Annonces() {
  const [items, setItems] = useState([]);
  const [term, setTerm] = useState("");
  const [sector, setSector] = useState("");
  const [state, setState] = useState("loading");

  const load = useCallback(async (t, s) => {
    setState("loading");
    let q = supabase
      .from("ww_listings")
      .select("id,title,description,price_amount,price_currency,city,images,sector_id,created_at,seller:ww_profiles(display_name,shop_name,whatsapp,plan)")
      .order("created_at", { ascending: false })
      .limit(40);
    if (s) q = q.eq("sector_id", Number(s));
    if (t) q = q.ilike("title", `%${t.replace(/[%_,()]/g, " ").trim()}%`);
    const { data, error } = await q;
    if (error) return setState("error");
    setItems(data || []);
    setState("ready");
  }, []);

  useEffect(() => {
    const s = new URLSearchParams(window.location.search).get("secteur") || "";
    setSector(s);
    load("", s);
  }, [load]);

  const sectorOf = (id) => sectors.find((x) => x.id === id);

  return (
    <div className="app">
      <header className="top"><h1 className="page-title" style={{ paddingLeft: 0 }}>Annonces</h1></header>

      <form className="search" onSubmit={(e) => { e.preventDefault(); load(term, sector); }} role="search">
        <input type="search" placeholder="Que recherchez-vous ?" aria-label="Rechercher" value={term} onChange={(e) => setTerm(e.target.value)} />
        <button type="submit" aria-label="Lancer la recherche">🔍</button>
      </form>
      <select className="filter" aria-label="Secteur" value={sector} onChange={(e) => { setSector(e.target.value); load(term, e.target.value); }}>
        <option value="">Tous les secteurs</option>
        {sectors.map((s) => <option key={s.id} value={s.id}>{s.emoji} {s.name}</option>)}
      </select>

      {state === "loading" && <p className="note">Chargement…</p>}
      {state === "error" && <p className="msg err">Impossible de charger les annonces. Vérifiez votre connexion.</p>}
      {state === "ready" && items.length === 0 && <p className="note">Aucune annonce pour le moment.</p>}

      <div className="stack" style={{ marginTop: 12 }}>
        {items.map((l) => {
          const sec = sectorOf(l.sector_id);
          const wa = l.seller?.whatsapp;
          return (
            <article key={l.id} className="card ad">
              <div className="ad-thumb">
                {l.images?.[0] ? <img src={l.images[0]} alt="" loading="lazy" /> : <span>{sec?.emoji || "📦"}</span>}
              </div>
              <div className="ad-body">
                <b>{l.title}</b>
                <span className="plan-price" style={{ textAlign: "left", fontSize: 15 }}>
                  <Price m={{ amount: Number(l.price_amount), cur: l.price_currency }} />
                </span>
                <small className="note">
                  {[sec?.name, l.city].filter(Boolean).join(" · ")}
                </small>
                <small className="note">
                  {l.seller?.shop_name || l.seller?.display_name}
                  {(l.seller?.plan === "pro" || l.seller?.plan === "b2b") && " ✓ Pro"}
                </small>
                {wa && (
                  <a className="btn small wa" target="_blank" rel="noopener noreferrer"
                     href={`https://wa.me/${wa}?text=${encodeURIComponent(`Bonjour, je suis intéressé par : ${l.title} (Wenze Wenze)`)}`}>
                    Contacter sur WhatsApp
                  </a>
                )}
              </div>
            </article>
          );
        })}
      </div>
    </div>
  );
}
