import { Sora } from "next/font/google";
import "./globals.css";
import RegisterSW from "./RegisterSW";
import CurrencyProvider from "./CurrencyProvider";
import AuthProvider from "./AuthProvider";
import TabBar from "./TabBar";

const sora = Sora({ subsets: ["latin"], weight: ["400", "500", "600", "700", "800"], display: "swap" });

export const metadata = {
  title: "Wenze Wenze Business",
  description: "Achetez. Vendez. Grandissez.",
  manifest: "/manifest.json",
  applicationName: "Wenze Wenze Business",
  appleWebApp: { capable: true, title: "Wenze Wenze", statusBarStyle: "default" },
  formatDetection: { telephone: false },
  icons: {
    icon: [
      { url: "/icons/icon-192.png", sizes: "192x192", type: "image/png" },
      { url: "/icons/icon-512.png", sizes: "512x512", type: "image/png" },
    ],
    apple: "/icons/apple-touch-icon.png",
  },
};

export const viewport = {
  themeColor: "#5B21B6",
  width: "device-width",
  initialScale: 1,
  viewportFit: "cover",
};

export default function RootLayout({ children }) {
  return (
    <html lang="fr">
      <body className={sora.className}>
        <CurrencyProvider>
          <AuthProvider>
            {children}
            <TabBar />
          </AuthProvider>
        </CurrencyProvider>
        <RegisterSW />
      </body>
    </html>
  );
}
