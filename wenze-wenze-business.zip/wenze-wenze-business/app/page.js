"use client";
import { useEffect, useState } from "react";
import InstallPrompt from "./InstallPrompt";
import Link from "next/link";
import Price from "./Price";
import { BoostCarousel, VideoRow } from "./HomeAds";
import CurrencyToggle from "./CurrencyToggle";
import { quick, videos, flash, shops, recommended, sectors } from "./data";

function useCountdown(hours = 6) {
  const [left, setLeft] = useState(hours * 3600);
  useEffect(() => {
    const t = setInterval(() => setLeft((s) => (s > 0 ? s - 1 : hours * 3600)), 1000);
    return () => clearInterval(t);
  }, [hours]);
  const p = (n) => String(n).padStart(2, "0");
  return [p(Math.floor(left / 3600)), p(Math.floor((left % 3600) / 60)), p(left % 60)];
}

function Section({ title, id, more = "Voir tout", href = "#", children }) {
  return (
    <section className="section" id={id}>
      <div className="section-head">
        <h2>{title}</h2>
        <a href={href} className="more">{more}</a>
      </div>
      {children}
    </section>
  );
}

export default function Home() {
  const [h, m, s] = useCountdown(6);

  return (
    <div className="app">
      <header className="top">
        <div className="brand">
          <span className="logo" aria-hidden="true">W</span>
          <div>
            <strong>Wenze Wenze</strong>
            <small>Business</small>
          </div>
        </div>
        <div className="top-actions">
          <CurrencyToggle />
          <Link href="/tarifs" className="tarifs-link">Tarifs</Link>
        </div>
      </header>

      <form className="search" onSubmit={(e) => e.preventDefault()} role="search">
        <input type="search" placeholder="Que recherchez-vous ?" aria-label="Rechercher" />
        <button type="submit" aria-label="Lancer la recherche">🔍</button>
      </form>

      <main>
        <div className="hero">
          <h1>Achetez. Vendez. Grandissez.</h1>
          <p>Tout ce dont vous avez besoin, au même endroit.</p>
          <div className="hero-cta">
            <Link href="/annonces" className="btn accent">Commencer à acheter</Link>
            <Link href="/vendre" className="btn outline">Ouvrir ma boutique</Link>
          </div>
        </div>

        <BoostCarousel />

        <nav className="quick" aria-label="Raccourcis">
          {quick.map((q) => (
            <button key={q.label}>
              <span>{q.icon}</span>
              {q.label}
            </button>
          ))}
        </nav>

        <Section title="Wenze Vidéo" id="videos">
          <VideoRow><div className="row">
            {videos.map((v) => (
              <article key={v.id} className="video" style={{ background: `linear-gradient(160deg, ${v.tone}, #1B1030)` }}>
                <span className="video-emoji">{v.emoji}</span>
                <span className="play" aria-hidden="true">▶</span>
                <div className="video-info">
                  <b>{v.title}</b>
                  <small>{v.shop} · {v.views} vues</small>
                </div>
              </article>
            ))}
          </div></VideoRow>
        </Section>

        <Section
          id="flash"
          title="Ventes flash"
          more={`${h}:${m}:${s}`}
        >
          <div className="row">
            {flash.map((p) => (
              <article key={p.id} className="card product">
                <div className="thumb">
                  <span className="badge">-{p.off}%</span>
                  {p.emoji}
                </div>
                <b><Price m={p.price} /></b>
                <s><Price m={p.old} single /></s>
                <span className="name">{p.name}</span>
              </article>
            ))}
          </div>
        </Section>

        <Section title="Boutiques populaires">
          <div className="grid shops">
            {shops.map((b) => (
              <article key={b.id} className="card shop">
                <span className="avatar">{b.emoji}</span>
                <b>{b.name}</b>
                <small>{b.cat}</small>
                <span className="rating">★ {b.rating} ({b.reviews})</span>
                <button className="btn small">Voir la boutique</button>
              </article>
            ))}
          </div>
        </Section>

        <Section title="Recommandé pour vous">
          <div className="grid products">
            {recommended.map((p) => (
              <article key={p.id} className="card product">
                <div className="thumb">{p.emoji}</div>
                <span className="name">{p.name}</span>
                <b><Price m={p.price} /></b>
                <span className="rating">★ {p.rating} ({p.reviews})</span>
              </article>
            ))}
          </div>
        </Section>

        <div className="boost">
          <div>
            <b>Boostez votre visibilité !</b>
            <p>Faites la promotion de vos produits avec une vidéo sponsorisée.</p>
            <Link href="/campagnes" className="btn accent small">Créer une campagne</Link>
          </div>
          <span aria-hidden="true">📣</span>
        </div>

        <Section title="Secteurs d'activité" href="/categories">
          <div className="grid sectors">
            {sectors.slice(0, 8).map((c) => (
              <Link key={c.id} href="/categories" className="sector">
                <span>{c.emoji}</span>
                {c.name}
              </Link>
            ))}
          </div>
        </Section>
      </main>

      <InstallPrompt />
    </div>
  );
}
