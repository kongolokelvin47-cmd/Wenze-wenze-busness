"use client";
import { useCurrency } from "./CurrencyProvider";
import { format } from "./lib/currency";

export default function Price({ m, single = false }) {
  const { display } = useCurrency();
  const other = display === "USD" ? "CDF" : "USD";
  return (
    <span className="price">
      {format(m, display)}
      {!single && <small className="alt">{format(m, other)}</small>}
    </span>
  );
}
