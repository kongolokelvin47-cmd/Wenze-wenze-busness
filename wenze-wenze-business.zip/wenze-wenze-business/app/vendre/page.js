"use client";
import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { supabase } from "../lib/supabase";
import { errMsg } from "../lib/errors";
import { compressImage } from "../lib/image";
import { useAuth } from "../AuthProvider";
import { sectors } from "../data";
import Price from "../Price";

function SellerForm({ onDone }) {
  const [f, setF] = useState({ name: "", shop: "", whatsapp: "", city: "" });
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState(null);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    const { error } = await supabase.rpc("ww_become_seller", {
      p_display_name: f.name, p_shop_name: f.shop, p_whatsapp: f.whatsapp, p_city: f.city,
    });
    setBusy(false);
    if (error) return setMsg(errMsg(error));
    onDone();
  }

  return (
    <form className="form" onSubmit={submit}>
      <p className="note">Créez votre profil vendeur : 3 annonces gratuites à vie, sans commission.</p>
      <label>Votre nom<input required value={f.name} onChange={set("name")} /></label>
      <label>Nom de la boutique (facultatif)<input value={f.shop} onChange={set("shop")} /></label>
      <label>Numéro WhatsApp (avec indicatif, ex. 243…)<input required inputMode="tel" value={f.whatsapp} onChange={set("whatsapp")} /></label>
      <label>Ville<input value={f.city} onChange={set("city")} /></label>
      {msg && <p className="msg err">{msg}</p>}
      <button className="btn block" disabled={busy}>{busy ? "Patientez…" : "Devenir vendeur"}</button>
    </form>
  );
}

function ListingForm({ user, account, onCreated }) {
  const [f, setF] = useState({ title: "", sector: "", description: "", price: "", cur: "USD", city: account?.city || "" });
  const [files, setFiles] = useState([]);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState(null);
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    try {
      const urls = [];
      for (const file of files.slice(0, 3)) {
        const blob = await compressImage(file);
        const path = `${user.id}/${crypto.randomUUID()}.jpg`;
        const { error: upErr } = await supabase.storage.from("ww-listings").upload(path, blob, { contentType: "image/jpeg" });
        if (upErr) throw upErr;
        urls.push(supabase.storage.from("ww-listings").getPublicUrl(path).data.publicUrl);
      }
      const { error } = await supabase.from("ww_listings").insert({
        title: f.title.trim(),
        sector_id: Number(f.sector),
        description: f.description.trim() || null,
        price_amount: Number(f.price),
        price_currency: f.cur,
        city: f.city.trim() || null,
        images: urls,
      });
      if (error) throw error;
      setF({ ...f, title: "", description: "", price: "" });
      setFiles([]);
      setMsg({ type: "ok", text: "Annonce publiée !" });
      onCreated();
    } catch (err) {
      setMsg({ type: "err", text: errMsg(err) });
    }
    setBusy(false);
  }

  return (
    <form className="form" onSubmit={submit}>
      <label>Titre<input required minLength={3} maxLength={120} value={f.title} onChange={set("title")} /></label>
      <label>Secteur
        <select required value={f.sector} onChange={set("sector")}>
          <option value="">Choisir…</option>
          {sectors.map((s) => <option key={s.id} value={s.id}>{s.emoji} {s.name}</option>)}
        </select>
      </label>
      <label>Description<textarea rows={4} maxLength={2000} value={f.description} onChange={set("description")} /></label>
      <div className="two">
        <label>Prix<input required type="number" min="0" step="any" inputMode="decimal" value={f.price} onChange={set("price")} /></label>
        <label>Devise
          <select value={f.cur} onChange={set("cur")}><option value="USD">$ (USD)</option><option value="CDF">FC (CDF)</option></select>
        </label>
      </div>
      <label>Ville<input value={f.city} onChange={set("city")} /></label>
      <label>Photos (3 maximum)
        <input type="file" accept="image/*" multiple onChange={(e) => setFiles(Array.from(e.target.files || []).slice(0, 3))} />
      </label>
      {msg && <p className={`msg ${msg.type}`}>{msg.text}</p>}
      <button className="btn block" disabled={busy}>{busy ? "Publication…" : "Publier l'annonce"}</button>
    </form>
  );
}

export default function Vendre() {
  const { user, account, loading, refresh } = useAuth();
  const [mine, setMine] = useState([]);

  const loadMine = useCallback(async () => {
    if (!user) return;
    const { data } = await supabase
      .from("ww_listings")
      .select("id,title,price_amount,price_currency,status,created_at")
      .eq("seller_id", user.id)
      .neq("status", "removed")
      .order("created_at", { ascending: false });
    setMine(data || []);
  }, [user]);

  useEffect(() => { if (account?.is_seller) loadMine(); }, [account?.is_seller, loadMine]);

  async function remove(id) {
    if (!confirm("Retirer cette annonce ? Elle ne redonne pas d'annonce gratuite.")) return;
    await supabase.from("ww_listings").update({ status: "removed" }).eq("id", id);
    loadMine();
  }

  if (loading) return <div className="app"><p className="note">Chargement…</p></div>;

  if (!user)
    return (
      <div className="app">
        <header className="top"><h1 className="page-title" style={{ paddingLeft: 0 }}>Vendre</h1></header>
        <p className="note">Connectez-vous pour ouvrir votre boutique et publier des annonces.</p>
        <Link href="/connexion" className="btn block" style={{ marginTop: 12 }}>Se connecter / S'inscrire</Link>
      </div>
    );

  const proActive = (account?.plan === "pro" || account?.plan === "b2b") && account?.plan_expires_at && new Date(account.plan_expires_at) > new Date();
  const quotaLeft = account?.free_listings_left ?? 0;
  const blocked = account?.is_seller && !proActive && quotaLeft <= 0;

  return (
    <div className="app">
      <header className="top"><h1 className="page-title" style={{ paddingLeft: 0 }}>Vendre</h1></header>

      {!account?.is_seller ? (
        <SellerForm onDone={refresh} />
      ) : (
        <>
          <p className="note">
            {proActive ? "Formule active : annonces illimitées." : `Annonces gratuites restantes : ${quotaLeft} / 3 (à vie).`}
          </p>
          {blocked ? (
            <div className="card" style={{ marginTop: 12 }}>
              <b>Quota gratuit atteint</b>
              <p className="note">Passez à Vendeur Pro (5 $/mois) ou publiez une annonce occasionnelle (3 $ / 5 jours).</p>
              <Link href="/tarifs" className="btn small">Voir les tarifs</Link>
            </div>
          ) : (
            <ListingForm user={user} account={account} onCreated={() => { refresh(); loadMine(); }} />
          )}

          {mine.length > 0 && (
            <section className="section">
              <div className="section-head"><h2>Mes annonces</h2></div>
              <div className="stack">
                {mine.map((l) => (
                  <article key={l.id} className="card plan">
                    <div className="plan-head">
                      <b>{l.title}</b>
                      <span className="plan-price"><Price m={{ amount: Number(l.price_amount), cur: l.price_currency }} /></span>
                    </div>
                    <p className="note">{l.status === "blocked" ? "Bloquée par la modération" : "En ligne"}</p>
                    {l.status === "active" && <button className="link" onClick={() => remove(l.id)}>Retirer</button>}
                  </article>
                ))}
              </div>
            </section>
          )}
        </>
      )}
    </div>
  );
}
