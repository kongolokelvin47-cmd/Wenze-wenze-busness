"use client";
import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { supabase } from "./lib/supabase";

const Ctx = createContext({ user: null, account: null, loading: true, refresh: async () => {}, signOut: async () => {} });
export const useAuth = () => useContext(Ctx);

export default function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [account, setAccount] = useState(null);
  const [loading, setLoading] = useState(true);

  const loadAccount = useCallback(async (u) => {
    if (!u) return setAccount(null);
    const { data } = await supabase.rpc("ww_my_account");
    setAccount(Array.isArray(data) ? data[0] ?? null : data ?? null);
  }, []);

  useEffect(() => {
    let active = true;
    supabase.auth.getSession().then(async ({ data }) => {
      if (!active) return;
      const u = data.session?.user ?? null;
      setUser(u);
      await loadAccount(u);
      if (active) setLoading(false);
    });
    const { data: sub } = supabase.auth.onAuthStateChange((_event, session) => {
      const u = session?.user ?? null;
      setUser(u);
      setTimeout(() => loadAccount(u), 0);
    });
    return () => {
      active = false;
      sub.subscription.unsubscribe();
    };
  }, [loadAccount]);

  const refresh = useCallback(() => loadAccount(user), [loadAccount, user]);
  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
    setAccount(null);
  }, []);

  return <Ctx.Provider value={{ user, account, loading, refresh, signOut }}>{children}</Ctx.Provider>;
}
