export const quick = [
  { icon: "❤️", label: "Favoris" },
  { icon: "🏪", label: "Boutiques" },
  { icon: "🔥", label: "Tendances" },
  { icon: "✨", label: "Nouveautés" },
  { icon: "👕", label: "Mode" },
  { icon: "📱", label: "Téléphones" },
  { icon: "💻", label: "Électronique" },
  { icon: "🏠", label: "Maison" },
  { icon: "🍎", label: "Alimentation" },
  { icon: "💄", label: "Beauté" },
];

export const videos = [
  { id: 1, title: "Nouvelle collection", shop: "Belle Mode", views: "3,2K", emoji: "👜", tone: "#7C3AED" },
  { id: 2, title: "Test smartphone A73", shop: "Tech World", views: "5,1K", emoji: "📱", tone: "#2563EB" },
  { id: 3, title: "Cuisine express", shop: "Maison Chic", views: "1,8K", emoji: "🍳", tone: "#EA580C" },
  { id: 4, title: "Robe élégante", shop: "Belle Mode", views: "2,4K", emoji: "👗", tone: "#DB2777" },
];

export const flash = [
  { id: 1, name: "Sac à dos sport", price: { amount: 78000, cur: "CDF" }, old: { amount: 120000, cur: "CDF" }, off: 35, emoji: "🎒" },
  { id: 2, name: "Montre connectée", price: { amount: 79500, cur: "CDF" }, old: { amount: 130000, cur: "CDF" }, off: 40, emoji: "⌚" },
  { id: 3, name: "Sac à main élégant", price: { amount: 57000, cur: "CDF" }, old: { amount: 95000, cur: "CDF" }, off: 40, emoji: "👜" },
  { id: 4, name: "Casque audio", price: { amount: 45000, cur: "CDF" }, old: { amount: 60000, cur: "CDF" }, off: 25, emoji: "🎧" },
];

export const shops = [
  { id: 1, name: "Tech World", cat: "Électronique", rating: 4.9, reviews: 328, emoji: "💻" },
  { id: 2, name: "Belle Mode", cat: "Mode & Accessoires", rating: 4.7, reviews: 392, emoji: "👗" },
  { id: 3, name: "Maison Chic", cat: "Maison & Déco", rating: 4.8, reviews: 244, emoji: "🛋️" },
  { id: 4, name: "Fresh Market", cat: "Alimentation", rating: 4.6, reviews: 126, emoji: "🥬" },
];

export const recommended = [
  { id: 1, name: "Chemise homme", price: { amount: 25000, cur: "CDF" }, rating: 4.5, reviews: 220, emoji: "👔" },
  { id: 2, name: "Smartphone A73", price: { amount: 189000, cur: "CDF" }, rating: 4.7, reviews: 392, emoji: "📱" },
  { id: 3, name: "Blender électrique", price: { amount: 40000, cur: "CDF" }, rating: 4.6, reviews: 146, emoji: "🥤" },
  { id: 4, name: "Robe élégante", price: { amount: 20000, cur: "CDF" }, rating: 4.8, reviews: 310, emoji: "👗" },
];

export const categories = [
  { id: 1, name: "Mode", count: "9 000 produits", emoji: "👕", tone: "#FDE2E4" },
  { id: 2, name: "Téléphones", count: "4 500 produits", emoji: "📱", tone: "#DDE7FF" },
  { id: 3, name: "Électronique", count: "6 200 produits", emoji: "🎧", tone: "#E9DDFF" },
  { id: 4, name: "Maison", count: "3 800 produits", emoji: "🏠", tone: "#FFE9CC" },
];

const usd = (amount) => ({ amount, cur: "USD" });

export const plans = [
  { id: "buyer", name: "Client / Acheteur", price: usd(0), period: "Gratuit", features: ["Recherche et annonces", "Profils professionnels", "Contact avec les vendeurs", "Messagerie intégrée"] },
  { id: "free", name: "Vendeur Freemium", price: usd(0), period: "À vie", features: ["Profil professionnel", "3 annonces gratuites à vie", "Demandes de renseignements"] },
  { id: "pro", name: "Vendeur Pro", price: usd(5), period: "par mois", features: ["Annonces illimitées", "Messagerie intégrée", "Gestion de la clientèle", "Statistiques de base"] },
  { id: "b2b", name: "Grossiste / Dépôt B2B", price: usd(25), period: "par mois", features: ["Annonces illimitées", "Demandes de devis B2B", "Sous-comptes employés", "Fonctions avancées grossistes"] },
];

export const ads = [
  { id: "boost", kind: "boost", name: "Boost Image", price: usd(2), period: "5 jours", note: "1 image, 1 annonce promue" },
  { id: "v-exp", kind: "video_exp", name: "Video Pub Express", price: usd(1), period: "2 jours", note: "1 vidéo (30 s conseillées, 60 s max)" },
  { id: "v-std", kind: "video_std", name: "Video Pub Standard", price: usd(3), period: "6 jours", note: "1 vidéo (30 s conseillées, 60 s max)" },
  { id: "v-mon", kind: "video_mon", name: "Video Pub Mensuelle", price: usd(15), period: "30 jours", note: "1 vidéo (30 s conseillées, 60 s max)" },
  { id: "occ", name: "Publication occasionnelle", price: usd(3), period: "5 jours", note: "1 annonce, sans abonnement" },
];

// Secteurs d'activité (numérotation d'origine conservée ; le n°7 est à définir)
export const sectors = [
  { id: 1, name: "Commerce et distribution", emoji: "🛍️" },
  { id: 2, name: "Commerce de gros et distribution B2B", emoji: "📦" },
  { id: 3, name: "Agriculture, élevage et pêche", emoji: "🌾" },
  { id: 4, name: "Construction et bâtiment", emoji: "🏗️" },
  { id: 5, name: "Réparation et maintenance", emoji: "🔧" },
  { id: 6, name: "Beauté, coiffure et bien-être", emoji: "💇" },
  { id: 8, name: "Transport, livraison et logistique", emoji: "🚚" },
  { id: 9, name: "Informatique, numérique et télécommunications", emoji: "💻" },
  { id: 10, name: "Restauration et hôtellerie", emoji: "🍽️" },
  { id: 11, name: "Artisanat et production", emoji: "🧵" },
  { id: 12, name: "Éducation et formation", emoji: "🎓" },
  { id: 13, name: "Services juridiques et professionnels", emoji: "⚖️" },
  { id: 14, name: "Santé et services paramédicaux", emoji: "🩺" },
  { id: 15, name: "Services à domicile et services aux particuliers", emoji: "🏠" },
  { id: 16, name: "Événementiel, culture et divertissement", emoji: "🎉" },
  { id: 17, name: "Automobile et mobilité", emoji: "🚗" },
  { id: 18, name: "Mode, textile et accessoires", emoji: "👗" },
  { id: 19, name: "Finance, assurance et services commerciaux", emoji: "💼" },
  { id: 20, name: "Industrie et activités manufacturières", emoji: "🏭" },
  { id: 21, name: "Énergie et environnement", emoji: "⚡" },
  { id: 22, name: "Sport et loisirs", emoji: "⚽" },
  { id: 23, name: "Animaux et services animaliers", emoji: "🐾" },
  { id: 24, name: "Tourisme et voyages", emoji: "✈️" },
];
