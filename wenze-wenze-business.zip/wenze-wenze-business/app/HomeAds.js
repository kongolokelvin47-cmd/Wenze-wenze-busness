"use client";
import { useEffect, useState } from "react";
import { supabase } from "./lib/supabase";
import Price from "./Price";

export const mediaUrl = (path) => supabase.storage.from("ww-ads").getPublicUrl(path).data.publicUrl;

const SELECT =
  "id,kind,title,media_path,media_type,listing:ww_listings(title,price_amount,price_currency),seller:ww_profiles(display_name,shop_name,whatsapp)";

function useCampaigns(kinds) {
  const [items, setItems] = useState([]);
  useEffect(() => {
    let ok = true;
    // La base ne renvoie que les campagnes validées et non expirées (règle RLS)
    supabase
      .from("ww_campaigns")
      .select(SELECT)
      .in("kind", kinds)
      .order("starts_at", { ascending: false })
      .limit(12)
      .then(({ data }) => ok && setItems(data || []));
    return () => { ok = false; };
  }, []); // eslint-disable-line react-hooks/exhaustive-deps
  return items;
}

const wa = (c) =>
  c.seller?.whatsapp
    ? `https://wa.me/${c.seller.whatsapp}?text=${encodeURIComponent(`Bonjour, je vous contacte via Wenze Wenze : ${c.title}`)}`
    : null;

export function BoostCarousel() {
  const items = useCampaigns(["boost"]);
  if (!items.length) return null;
  return (
    <section className="section" aria-label="À la une">
      <div className="section-head"><h2>À la une</h2><span className="tag">Sponsorisé</span></div>
      <div className="row">
        {items.map((c) => {
          const href = wa(c);
          const Tag = href ? "a" : "div";
          return (
            <Tag key={c.id} className="boost-card" {...(href ? { href, target: "_blank", rel: "noopener noreferrer" } : {})}>
              <img src={mediaUrl(c.media_path)} alt="" loading="lazy" />
              <div className="boost-info">
                <b>{c.title}</b>
                {c.listing && (
                  <small><Price m={{ amount: Number(c.listing.price_amount), cur: c.listing.price_currency }} single /></small>
                )}
                <small>{c.seller?.shop_name || c.seller?.display_name}</small>
              </div>
            </Tag>
          );
        })}
      </div>
    </section>
  );
}

// Affiche les vraies vidéos publicitaires ; sinon le contenu de démonstration (children)
export function VideoRow({ children }) {
  const items = useCampaigns(["video_exp", "video_std", "video_mon"]);
  if (!items.length) return children;
  return (
    <div className="row">
      {items.map((c) => (
        <article key={c.id} className="vid">
          <video src={mediaUrl(c.media_path)} controls muted playsInline preload="metadata" />
          <div className="vid-info">
            <b>{c.title}</b>
            <small>{c.seller?.shop_name || c.seller?.display_name} · Sponsorisé</small>
            {wa(c) && <a href={wa(c)} target="_blank" rel="noopener noreferrer" className="btn small wa">WhatsApp</a>}
          </div>
        </article>
      ))}
    </div>
  );
}
