# Wenze Wenze Business (PWA)

Next.js (App Router) · PWA installable · français · prix en CDF.

## Lancer
```bash
npm install
npm run dev            # développement (service worker désactivé)
npm run build && npm start   # production (service worker actif, installable)
```
Pour tester l'installation : `npm run build && npm start`, puis ouvrir
http://localhost:3000 dans Chrome → menu → « Installer l'application ».
En ligne, la PWA exige HTTPS (Vercel, Netlify, Cloudflare Pages le fournissent).

## Structure
- `app/layout.js` : métadonnées, police, thème, enregistrement du SW
- `app/page.js` : écran d'accueil (hero, vidéos, ventes flash, boutiques, catégories)
- `app/data.js` : données de démonstration (à remplacer par votre API / base)
- `app/InstallPrompt.js` : bandeau « Installer »
- `public/manifest.json`, `public/sw.js`, `public/offline.html`, `public/icons/*`

## Supabase (étape 1 : comptes, vendeurs, annonces)
Tables préfixées `ww_` dans le projet Supabase (déjà créées) : `ww_sectors`, `ww_profiles`, `ww_listings`, `ww_admins`,
bucket photos `ww-listings`. Variables : voir `.env.example` (les valeurs par défaut sont déjà dans le code).

- Quota des 3 annonces gratuites à vie : appliqué en base (trigger), impossible à contourner depuis le navigateur.
- Un numéro WhatsApp = un compte vendeur (anti-doublons).
- Devenir administrateur (une seule fois, dans l'éditeur SQL de Supabase) :
  `insert into public.ww_admins (user_id) select id from auth.users where email = 'VOTRE_EMAIL';`
- Activer un abonnement après paiement Mobile Money (admin connecté) :
  `select public.ww_admin_set_plan('<id_vendeur>', 'pro', now() + interval '30 days');`
- Auth > URL Configuration : ajouter l'adresse du site publié (Vercel) dans « Site URL » et « Redirect URLs ».

## Abonnements et paiements (étape 3)
- `/abonnement` : le vendeur choisit Pro ou B2B, paie en Mobile Money, envoie la référence + une capture d'écran (bucket privé `ww-proofs`).
- `/admin` (réservé aux admins) : valider / rejeter les demandes (l'abonnement est activé pour 30 jours, ou prolongé s'il est déjà actif),
  modifier le taux FC/$ et les instructions de paiement. **Renseignez vos numéros Mobile Money dans « Réglages » avant d'ouvrir au public.**
- Une même référence de transaction ne peut pas être utilisée deux fois ; une seule demande en attente par formule.
- Les prix sont dans la table `ww_offers` (modifiables dans l'éditeur SQL de Supabase).

## Campagnes publicitaires (étape 4)
- `/campagnes` : le vendeur crée une campagne (Boost Image ou Video Pub), envoie son média (image compressée ; vidéo MP4/WebM/MOV de 60 s et 20 Mo maximum),
  puis paie (même circuit Mobile Money que les abonnements).
- `/admin` : la carte de paiement affiche le visuel/la vidéo. « Valider » met la campagne en ligne pour sa durée (2, 5, 6 ou 30 jours) ;
  l'onglet « En ligne » permet d'arrêter une campagne non conforme.
- Accueil : carrousel « À la une » (Boost Image) et vidéos réelles dans Wenze Vidéo (la démo s'affiche tant qu'aucune campagne n'est en ligne).
- L'expiration est automatique : la base ne renvoie que les campagnes validées et non terminées. Aucun renouvellement automatique.

## Mise en ligne (Netlify, offre gratuite)
1. Pousser le dossier sur un dépôt GitHub (le fichier `.env.local` n'est pas envoyé ; les valeurs par défaut sont dans le code).
2. Netlify > Add new project > Import from Git > choisir le dépôt > Deploy (Next.js est détecté automatiquement, `netlify.toml` fixe Node 20).
3. Supabase > Authentication > URL Configuration : mettre l'adresse Netlify dans « Site URL » et l'ajouter dans « Redirect URLs ».
4. Ouvrir le site, créer un compte, puis lancer la commande SQL « devenir admin » (section Supabase ci-dessus) et renseigner vos numéros Mobile Money dans /admin > Réglages.
Note : Vercel (offre gratuite « Hobby ») est réservé à un usage non commercial ; ne pas l'utiliser une fois les paiements ouverts.
